import { Component } from '@angular/core';
import { FormBuilder, FormGroup,  Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
loginForm: FormGroup;

  constructor(private fb: FormBuilder,private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  get email() {
    return this.loginForm.get('email');
  }

  get password() {
    return this.loginForm.get('password');
  }

  onSubmit() {
    if (this.loginForm.valid) {
      const formData = this.loginForm.value; // 👈 retrieve form data
      console.log('Form Data:', formData);
      console.log('Email:', formData.email);
      console.log('Password:', formData.password);

      if (formData.email == 'amit@gmail.com' && formData.password == '123456') {
        console.log('✅ Login successful!', this.loginForm.value);
        alert('Login successful!');
        this.router.navigate(['/home']); // 👈 navigate to Home component
      }
      else {
        console.log('Login Failed!', this.loginForm.value);
        alert('Login Failed!');
      }
    }
  }
}
