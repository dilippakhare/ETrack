import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { SelectGroupComponent } from '../feature/customer/select-group/select-group.component';
import { SelectionDialogComponent } from '../common/selection-dialog/selection-dialog.component';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  today: Date;

  selectedItem: any;
  options = [
    { id: 1, name: 'Schedule Visit' ,type : 'Service' },
    { id: 2, name: 'View Pending Visits' ,type : 'Service'},
    { id: 3, name: 'View All Visits' ,type : 'Service'},
    { id: 4, name: 'Schedule Visit' ,type : 'Sales' },
    { id: 5, name: 'View Pending Visits' ,type : 'Sales'},
    { id: 6, name: 'View All Visits' ,type : 'Sales'},
    { id: 7, name: 'Book Complaint' ,type : 'Complaint' },
    { id: 8, name: 'View Complaint' ,type : 'Complaint'},
    { id: 9, name: 'My Complaint' ,type : 'Complaint'},
    { id: 10, name: 'Apply Leave' ,type : 'Leave'},
    { id: 11, name: 'View Leave' ,type : 'Leave'},
  ];

  constructor(public dialog: MatDialog, private router: Router) {
    this.today = new Date();
  }

  openMyDialog(): void {
    const dialogRef = this.dialog.open(SelectGroupComponent, {
      width: '450px', // Optional: set width
      data: { message: 'Hello from parent!' } // Optional: pass data
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`); // Log the result
    });
  }

  serviceMenu() {
    //alert("Service Visit");
    this.openSelectionDialog(this.options.filter(x=>x.type === "Service"));
  }

  salesMenu() {
    //alert("Service Visit");
    this.openSelectionDialog(this.options.filter(x=>x.type === "Sales"));
  }

  complaintMenu() {
    //alert("Service Visit");
    this.openSelectionDialog(this.options.filter(x=>x.type === "Complaint"));
  }

  leaveMenu() {
    //alert("Service Visit");
    this.openSelectionDialog(this.options.filter(x=>x.type === "Leave"));
  }


  openSelectionDialog(menus:SubMenus[]): void {
    const dialogRef = this.dialog.open(SelectionDialogComponent, {
      width: '400px',
      data: { options: menus },
    });

    dialogRef.afterClosed().subscribe(result => {
      
      if (result) {
        this.selectedItem = result.data;
       
        if(this.selectedItem.id === 1)
         this.router.navigate(['/sch_Svisit']);
        else  if(this.selectedItem.id === 2)
         this.router.navigate(['/sch_Pvisit']);
        else  if(this.selectedItem.id === 3)
         this.router.navigate(['/sch_Pvisit']);

      }
    });
  }
}

interface SubMenus {
  id: number;
  name: string;
  type: string;
}
