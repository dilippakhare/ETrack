import { Injectable } from "@angular/core";
import { GroupModel } from "../../model/GroupModel";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";


@Injectable({
  providedIn: 'root'
})
export class GroupService {
  private apiUrl = 'http://localhost:3000/groups'; // Example API endpoint

  constructor(private http: HttpClient) { }

  getGroups(str:string): Observable<GroupModel[]> {
   // var url = this.apiUrl+"?groupName="+str;
    return this.http.get<GroupModel[]>(this.apiUrl);
  }
}