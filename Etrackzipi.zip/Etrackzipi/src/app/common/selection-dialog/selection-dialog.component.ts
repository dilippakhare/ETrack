import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-selection-dialog',
  standalone: false,
  template: `
    <h2 mat-dialog-title>Select an Option</h2>
    <!--
    <mat-dialog-content>
      <mat-selection-list #options (selectionChange)="onSelectionChange()">
        <mat-list-option *ngFor="let option of data.options" [value]="option">
          {{ option.name }}
        </mat-list-option>
      </mat-selection-list>
    </mat-dialog-content>
    <mat-dialog-actions>
      <button mat-button (click)="onCancel()">Cancel</button>
      <button mat-button [mat-dialog-close]="selectedOption" [disabled]="!selectedOption">Select</button>
    </mat-dialog-actions>-->

    <mat-dialog-content>
      <mat-list>
      <ng-container *ngFor="let item of data.options; let last = last">
         <mat-list-item  (click)="seletcedItem(item)">{{ item.name }}</mat-list-item>
         <mat-divider *ngIf="!last"></mat-divider>
      </ng-container>
      </mat-list>
    </mat-dialog-content>
  `,
})
export class SelectionDialogComponent {
  selectedOption: any;

  constructor(
    public dialogRef: MatDialogRef<SelectionDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { options: any[] }
  ) { }

  onSelectionChange(): void {
    //this.selectedOption = this.selectedOptions.selected[0]?.value;
  }

  onCancel(): void {
    this.dialogRef.close({ data: this.selectedOption, status: 'success' });
  }
  seletcedItem(option:any){
     //alert(JSON.stringify(option));
     this.selectedOption =option;
     
     this.onCancel();
  }
}