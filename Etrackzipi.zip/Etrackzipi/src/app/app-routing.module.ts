import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ScheduleServiceVisitComponent } from './feature/service/schedule-service-visit/schedule-service-visit.component';
import { PendingVisitComponent } from './feature/service/pending-visit/pending-visit.component';
import { ServiceVisitDetailsComponent } from './feature/service/service-visit-details/service-visit-details.component';

export const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'sch_Svisit', component: ScheduleServiceVisitComponent },
  { path: 'sch_Pvisit', component: PendingVisitComponent },
  { path: 'visitdetails/:token', component: ServiceVisitDetailsComponent },
  { path: '**', redirectTo: '' } // fallback route
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
