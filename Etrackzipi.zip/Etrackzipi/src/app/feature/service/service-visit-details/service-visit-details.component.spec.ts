import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceVisitDetailsComponent } from './service-visit-details.component';

describe('ServiceVisitDetailsComponent', () => {
  let component: ServiceVisitDetailsComponent;
  let fixture: ComponentFixture<ServiceVisitDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ServiceVisitDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServiceVisitDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
