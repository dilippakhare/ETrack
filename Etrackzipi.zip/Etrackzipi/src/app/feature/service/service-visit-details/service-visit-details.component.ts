import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-service-visit-details',
  standalone: false,
  templateUrl: './service-visit-details.component.html',
  styleUrl: './service-visit-details.component.css'
})
export class ServiceVisitDetailsComponent {
token!: string;
constructor(private route: ActivatedRoute) {}

ngOnInit() {
  this.route.params.subscribe(params => {
    this.token = params['token']; // Access the 'id' parameter
    // Use productId to fetch product details
    alert(this.token);
  });
}

}
