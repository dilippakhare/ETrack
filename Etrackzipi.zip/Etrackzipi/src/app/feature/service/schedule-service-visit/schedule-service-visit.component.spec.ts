import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ScheduleServiceVisitComponent } from './schedule-service-visit.component';

describe('ScheduleServiceVisitComponent', () => {
  let component: ScheduleServiceVisitComponent;
  let fixture: ComponentFixture<ScheduleServiceVisitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ScheduleServiceVisitComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ScheduleServiceVisitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
