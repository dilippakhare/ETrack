import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { map, startWith, subscribeOn } from 'rxjs/operators';
import { AsyncPipe } from '@angular/common';
import { GroupModel } from '../../../model/GroupModel';
import { GroupService } from '../../../common/services/GroupServices';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';

@Component({
  selector: 'app-schedule-service-visit',
  standalone: false,
  templateUrl: './schedule-service-visit.component.html',
  styleUrl: './schedule-service-visit.component.css'
})
export class ScheduleServiceVisitComponent {
  scheduleForm: FormGroup;
  selectedGroupValue: string = '';

  subscription: Subscription | undefined;

  constructor(private fb: FormBuilder, private router: Router, private groupService: GroupService) {
    this.scheduleForm = this.fb.group({
      group: ['', [Validators.required]],
      visitType: ['', [Validators.required]],
      reason: ['', [Validators.required]],
      scheduleDate: ['', [Validators.required]],
      engineerId: ['', [Validators.required]],
    });
  }

  // groups: string[] = [];
  groupsList: GroupModel[] = [
    { id: 1, groupName: 'Virat' },
    { id: 2, groupName: 'Rahul' },
    { id: 3, groupName: 'sachin' }];

  filteredGroups!: Observable<GroupModel[]>;

  ngOnInit() {
    this.filteredGroups = this.groupService.getGroups(this.scheduleForm.controls['group'].value);
    /*this.filteredGroups = this.scheduleForm.controls['group'].valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );*/

    this.scheduleForm.controls['group'].valueChanges.subscribe(res => {
      console.log((new Date()))
      if (this.subscription != null)
        this.subscription.unsubscribe();
      this.filteredGroups = this.groupService.getGroups(this.scheduleForm.controls['group'].value);
      this.subscription = this.filteredGroups.subscribe();
    })
  }

  
  private _filter(value: any): GroupModel[] {
    if (typeof value !== 'string') {
      const filterValue = this._normalizeValue(value.groupName);
      return this.groupsList.filter(groups => this._normalizeValue(groups.groupName).includes(filterValue));
    }
    else {
      const filterValue = this._normalizeValue(value);
      return this.groupsList.filter(groups => this._normalizeValue(groups.groupName).includes(filterValue));
    }
  }

  private _normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, '');
  }
  selectedValue(value: GroupModel) {
    this.selectedGroupValue = value.groupName;
    alert("Selected value:-" + value);
  }
  selectedValue1(value: Event) {
    //this.selectedGroupValue = value.v.groupName;
    alert("Selected value:-" + value);
  }

  onGroupSelected(event: MatAutocompleteSelectedEvent): void {
    console.log('Option selected via Enter:', event.option.value);
    this.scheduleForm.controls['group'].patchValue(event.option.value);
    this.selectedGroupValue = event.option.value.groupName;
    // Your custom logic here
  }
  editGroup() {
    //alert("cliked");
    this.scheduleForm.controls['group'].patchValue("");
    this.selectedGroupValue = "";
  }


  scheduleVisit() {
    
  }
}
