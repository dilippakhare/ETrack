import { Component } from '@angular/core';
import { Router } from '@angular/router';
export interface Section {
  EmployeeName: string;
  ScheduleDate: Date;
  GroupName: string;
  VisitId: string;
  VisitToken: string;
  Status: string;
}
@Component({
  selector: 'app-pending-visit',
  standalone: false,
  templateUrl: './pending-visit.component.html',
  styleUrl: './pending-visit.component.css'
})
export class PendingVisitComponent {

  constructor( private router: Router) {

  }

  gotoVisitDetails(_visit: Section) {
      this.router.navigate(['/visitdetails', _visit.VisitToken]);
  }


  visits: Section[] = [
    {
      EmployeeName: 'Photos',
      ScheduleDate: new Date('1/1/16'),
      GroupName: 'AchalKar',
      VisitId: '1',
      VisitToken: '1',
      Status: 'Schedule'


    },
    {
      EmployeeName: 'Recipes',
      ScheduleDate: new Date('1/17/16'),
      GroupName: 'AchalKar',
      VisitId: '2',
      VisitToken: '2',
      Status: 'In-Progress'
    },
    {
      EmployeeName: 'Work',
      ScheduleDate: new Date('1/28/16'),
      GroupName: 'AchalKar',
      VisitId: '3',
      VisitToken: '3',
      Status: 'Completed'
    },
  ];

}
