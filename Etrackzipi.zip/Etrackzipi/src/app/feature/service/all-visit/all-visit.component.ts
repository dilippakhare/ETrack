import { Component } from '@angular/core';

@Component({
  selector: 'app-all-visit',
  standalone: false,
  templateUrl: './all-visit.component.html',
  styleUrl: './all-visit.component.css'
})
export class AllVisitComponent {

}
