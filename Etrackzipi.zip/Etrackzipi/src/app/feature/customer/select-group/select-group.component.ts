import { Component } from '@angular/core';
import {  Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-select-group',
  standalone: false,
  templateUrl: './select-group.component.html',
  styleUrl: './select-group.component.css'
})
export class SelectGroupComponent {
 constructor(
        public dialogRef: MatDialogRef<SelectGroupComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any // Optional: for passing data
      ) {}

      onNoClick(): void {
        this.dialogRef.close();
      }

      // You can also pass a result when closing
      onConfirmClick(): void {
        this.dialogRef.close('Confirmed!');
      }
}
