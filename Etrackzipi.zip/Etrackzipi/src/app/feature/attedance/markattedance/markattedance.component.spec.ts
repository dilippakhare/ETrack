import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MarkattedanceComponent } from './markattedance.component';

describe('MarkattedanceComponent', () => {
  let component: MarkattedanceComponent;
  let fixture: ComponentFixture<MarkattedanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MarkattedanceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MarkattedanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
