import { Component } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Inject } from '@angular/core';

@Component({
  selector: 'app-markattedance',
  standalone: false,
  templateUrl: './markattedance.component.html',
  styleUrl: './markattedance.component.css'
})
export class MarkattedanceComponent {
  selected = '';
  isChecked: boolean = false; // Initial state

  startKM = '';
  endKM = ''

  constructor(public dialogRef: MatDialogRef<MarkattedanceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any // Optional: for passing data)
  ) {

  }
  updateTA() {

  }
  submitAttendanc() {
     this.dialogRef.close();
  }
}
