import { ChangeDetectionStrategy, Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MarkattedanceComponent } from '../markattedance/markattedance.component';

@Component({
  selector: 'app-attendance-view',
  standalone: false,
  templateUrl: './attendance-view.component.html',
  styleUrl: './attendance-view.component.css',
   changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AttendanceViewComponent {

  constructor(public dialog: MatDialog) { 
         
  }

  markAttendance() {
  
         const dialogRef = this.dialog.open(MarkattedanceComponent, {
           width: '500px', // Optional: set width
           data: { message: 'Hello from parent!' } // Optional: pass data
         });
     
         dialogRef.afterClosed().subscribe(result => {
           console.log(`Dialog result: ${result}`); // Log the result
         });
       
  }
}
