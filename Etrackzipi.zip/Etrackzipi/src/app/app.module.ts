import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { SelectGroupComponent } from './feature/customer/select-group/select-group.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button'; // For buttons in dialog
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {MatCardModule} from '@angular/material/card';
import {MatSelectModule} from '@angular/material/select';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {FormsModule} from '@angular/forms';
import {MatDividerModule} from '@angular/material/divider';
import { MatGridListModule, MatGridList } from '@angular/material/grid-list';

import { MatListModule } from '@angular/material/list';
import { MatAutocompleteModule, MatAutocomplete } from '@angular/material/autocomplete';
import {MatInputModule} from '@angular/material/input';
import { HttpClientModule } from '@angular/common/http'; 
import {MatIconModule} from '@angular/material/icon';



//------------------------//
import { AttendanceViewComponent } from './feature/attedance/attendance-view/attendance-view.component';
import { MarkattedanceComponent } from './feature/attedance/markattedance/markattedance.component';
import { SelectionDialogComponent } from './common/selection-dialog/selection-dialog.component';
import { ScheduleServiceVisitComponent } from './feature/service/schedule-service-visit/schedule-service-visit.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } 
    from '@angular/material/core';
import { PendingVisitComponent } from './feature/service/pending-visit/pending-visit.component';
import { AllVisitComponent } from './feature/service/all-visit/all-visit.component';
import { ServiceVisitDetailsComponent } from './feature/service/service-visit-details/service-visit-details.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    SelectGroupComponent,
    AttendanceViewComponent,
    MarkattedanceComponent,
    SelectionDialogComponent,
    ScheduleServiceVisitComponent,
    PendingVisitComponent,
    AllVisitComponent,
    ServiceVisitDetailsComponent
  ],
  imports: [
    AppRoutingModule,
    CommonModule,
    ReactiveFormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatDialogModule,
    MatButtonModule,
    NgbModule,
    MatCardModule,
    MatSelectModule,
    MatFormFieldModule,
    MatCheckboxModule,
    FormsModule,
    MatDividerModule,
    MatGridListModule,
    MatGridList,
    MatListModule,
    MatAutocomplete,
    MatAutocompleteModule,
    MatInputModule,
    HttpClientModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatListModule, MatIconModule, MatDividerModule
],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
