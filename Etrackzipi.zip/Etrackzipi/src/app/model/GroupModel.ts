export class GroupModel {
  // Properties
  id!: number;
  groupName!: string;
}