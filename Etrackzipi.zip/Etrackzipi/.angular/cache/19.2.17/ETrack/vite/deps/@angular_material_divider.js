import {
  MatDivider,
  MatDividerModule
} from "./chunk-WSZWMXUN.js";
import "./chunk-JXBCBRYI.js";
import "./chunk-HQPZL5RQ.js";
import "./chunk-ITN3MZOV.js";
import "./chunk-BKT6D2HE.js";
import "./chunk-BHNWYPV7.js";
import "./chunk-WW4QWPVU.js";
import "./chunk-23KEF57A.js";
import "./chunk-Z2MIX22O.js";
export {
  MatDivider,
  MatDividerModule
};
